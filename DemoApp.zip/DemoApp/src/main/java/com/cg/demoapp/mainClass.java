package com.cg.demoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class mainClass {
 public static void main(String args[]) {
	 SpringApplication.run(mainClass.class,args);
 }
}
