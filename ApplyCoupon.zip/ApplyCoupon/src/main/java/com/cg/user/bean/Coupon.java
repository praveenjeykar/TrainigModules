package com.cg.user.bean;

public class Coupon {

}
