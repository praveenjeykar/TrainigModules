package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.bean.Product;
import com.cg.product.exception.ProductException;
import com.cg.product.service.IProductService;



@RestController
public class ProductController {

	@Autowired
    IProductService iproductService;
	
	@RequestMapping(value="/products",method=RequestMethod.POST)
	public List<Product> CreateProduct(@RequestBody Product pro) throws ProductException{
		return iproductService.CreateProduct(pro);
	}
	
	@RequestMapping(value="/products/{id}",method=RequestMethod.PUT) 
	public List<Product> UpdateProduct(@PathVariable String id,@RequestBody Product prod) throws ProductException{
		return iproductService.UpdateProduct(id, prod);       
	}
	
	@DeleteMapping("/products/{id}")
	public ResponseEntity<String> DeleteProduct(@PathVariable String id) throws ProductException{
		iproductService.DeleteProduct(id);
		return new ResponseEntity<String>("customer with "+id+" deleted", HttpStatus.OK);
	}
	
	@RequestMapping("/products")
	public List<Product> ViewProducts() throws ProductException {
	return iproductService.ViewProducts();
	}
	
	@RequestMapping("/products/{id}")
	public Product FindProduct(@PathVariable String id)throws ProductException {
		return iproductService.FindProduct(id);
	}
	
}
