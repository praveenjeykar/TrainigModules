package com.cg.product.service;

import java.util.List;

import com.cg.product.bean.Product;
import com.cg.product.exception.ProductException;

public interface IProductService {
	public List<Product> CreateProduct(Product pro) throws ProductException;
	public List<Product> UpdateProduct(String id,Product pro) throws ProductException;
	public void DeleteProduct(String Id) throws ProductException;
	public List<Product> ViewProducts() throws ProductException;
	public Product FindProduct(String Id) throws ProductException;
}
