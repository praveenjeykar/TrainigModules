package com.cg.user.service;

import java.util.List;

import com.cg.user.bean.Coupon;



public interface CouponService {
	public double ApplyDiscount(String prodId);
	public Coupon displayDiscount(String couponCode);
	public List<Coupon> addCoupon(Coupon coupon);
}
