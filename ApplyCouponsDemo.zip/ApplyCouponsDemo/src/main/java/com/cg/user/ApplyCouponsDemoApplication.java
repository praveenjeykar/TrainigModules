package com.cg.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplyCouponsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplyCouponsDemoApplication.class, args);
	}

}
