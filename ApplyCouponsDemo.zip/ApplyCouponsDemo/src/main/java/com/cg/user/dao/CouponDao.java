package com.cg.user.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.user.bean.Coupon;


@Repository
public interface CouponDao extends JpaRepository<Coupon, String>{
	@Query("from Coupon where prodId=:proid")
	Coupon getCouponById(@Param("proid") String prodId);
}
