package com.cg.cust.service;

import com.cg.cust.bean.Customer;
import com.cg.cust.exception.CustomerException;
import java.util.List;

import org.springframework.stereotype.Service;

public interface CustomerService {
   public List<Customer> getAllCustomers() throws CustomerException;
   public Customer getCustomerById(int Id) throws CustomerException;
   public List<Customer> addCustomer(Customer cust) throws CustomerException;
   public List<Customer> updateCustomer(int id,Customer cust) throws CustomerException;
   public void deleteCustomer(int Id) throws CustomerException;
   public List<Customer> getACustomerByCity(String city) throws CustomerException;
   
}
