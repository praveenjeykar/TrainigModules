package com.cg.session.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.session.bean.Session;
import com.cg.session.dao.SessionDao;
import com.cg.session.exception.SessionException;
@Service
public class SessionServiceImpl implements SessionService{
	@Autowired
	SessionDao sessionDao;
	@Override
	
//	Author: MonicaBeera
//	DateOdCreation: 30-07-2019
//	MethodName: getAllsessions
//	return value: returns the Session List
//	Purpose: to get session details from Session Database		
  
	public List<Session> getAllSessions() throws SessionException {
	try {
          return sessionDao.findAll();
	}
		catch(Exception e) {
			throw new SessionException(e.getMessage());
    }
	}

	
	@Override
	public Session getSessionById(int Id) throws SessionException {
		try{
			return sessionDao.findById(Id).get();
		}
	  catch(Exception e) {
		throw new SessionException(e.getMessage());
	}
	}
	

	
	public List<Session> addSession(Session ses) throws SessionException {
		try {
			sessionDao.save(ses);
			return sessionDao.findAll();
		}
		 catch(Exception e) {
				throw new SessionException(e.getMessage());
	}
	}


//	@Override
//	public List<Session> updateSession(int Id, Session ses) throws SessionException {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public void deleteSession(int Id) throws SessionException {
		try {
			sessionDao.deleteById(Id);
		}
		catch(Exception e) {
			throw new SessionException(e.getMessage());
	}
	}


@Override
public List<Session> updateDuration(int id, Session duration) throws SessionException {
	try {
		Session session=sessionDao.findById(id).get();
       session.setDuration(duration.getDuration());
       sessionDao.save(session);
       return getAllSessions();  
}
	catch(Exception e) {
		throw new SessionException(e.getMessage());
}
}
@Override
public List<Session> updateFaculty(int id, Session faculty) throws SessionException {
	try {
		Session session=sessionDao.findById(id).get();
        session.setFaculty(faculty.getFaculty());
        sessionDao.save(session);
        return getAllSessions();            
 }
	catch(Exception e) {
		throw new SessionException(e.getMessage());
	}
}
}
//
//	@Override
//	public List<Session> getSessionByfaculty(String faculty) throws SessionException {
//		// TODO Auto-generated method stub
//		return null;
//	}

