package com.cg.session.service;
import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;
import java.util.List;

public interface SessionService {
   public List<Session> getAllSessions() throws SessionException;
   public Session getSessionById(int Id) throws SessionException;
   public List<Session> addSession(Session sess) throws SessionException;
   public void deleteSession(int Id) throws SessionException;
   public List<Session> updateDuration(int id, Session duration) throws SessionException ;
   public List<Session> updateFaculty(int id, Session faculty) throws SessionException;
//}//   public List<Session> updateSession(int Id,Session ses) throws SessionException;
// public List<Session> getSessionByfaculty(String faculty) throws SessionException;
}
