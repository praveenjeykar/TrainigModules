package com.cg.session.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;
import com.cg.session.service.SessionService;

@RestController
public class SessionController {
	
	@Autowired
    SessionService sessionService;
	@RequestMapping("/sessions")
	public List<Session> getAllSessions() throws SessionException {
	return sessionService.getAllSessions();
	}

@RequestMapping("/sessions/{id}")
public Session getSessionById(@PathVariable int id)throws SessionException {
	return sessionService.getSessionById(id);
}
@RequestMapping(value="/sessions",method=RequestMethod.POST)
public List<Session> addSession(@RequestBody Session sess) throws SessionException{
	return sessionService.addSession(sess);
}

@DeleteMapping("/sessions/{id}")
public ResponseEntity<String> deleteSession(@PathVariable int id) throws SessionException{
	sessionService.deleteSession(id);
	return new ResponseEntity<String>("customer with "+id+" deleted", HttpStatus.OK);
}

@RequestMapping(value="/updateduration/{id}",method=RequestMethod.PUT) 
public List<Session> updateDuration(@PathVariable int id,@RequestBody Session duration) throws SessionException{
    return sessionService.updateDuration(id, duration);       
}


@RequestMapping(value="/updatefaculty/{id}",method=RequestMethod.PUT)
public List<Session> updateFaculty(@PathVariable int id,@RequestBody Session faculty) throws SessionException{
    return sessionService.updateFaculty(id, faculty);       
}
}
