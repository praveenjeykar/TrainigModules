package com.cg.demo1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo1.Exception.DemoException;
import com.cg.demo1.bean.demo1;
import com.cg.demo1.dao.Idemo1;

@Service
public class demo1serviceImpl implements demo1Service{
	@Autowired
	Idemo1 idemo;
	demo1 demo;

	@Override
	public int Applydemo1(String couponcode, int discount) throws DemoException {		
		int price = (idemo.getPriceByCoupon(couponcode))-((idemo.getPriceByCoupon(couponcode)*idemo.getPriceByDiscount(discount))/100);
		demo.setPrice(price);
		return idemo.getPriceByCoupon(couponcode);
	}

	@Override
	public void adddemo1(demo1 dem) {
		idemo.save(dem);
		
		
	}

	
	
}
