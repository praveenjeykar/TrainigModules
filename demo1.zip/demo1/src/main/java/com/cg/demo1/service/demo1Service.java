package com.cg.demo1.service;

import java.util.List;

import com.cg.demo1.Exception.DemoException;
import com.cg.demo1.bean.demo1;



public interface demo1Service {
	
	public int Applydemo1(String couponcode,int discount) throws DemoException;
	void adddemo1(demo1 dem);	
}
