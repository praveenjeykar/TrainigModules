package com.cg.demo1.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.demo1.Exception.DemoException;
import com.cg.demo1.bean.demo1;
import com.cg.demo1.service.demo1Service;


@RestController
public class demo1controller {
	@Autowired
	demo1Service demoservice;
	@RequestMapping(value="/couponss/{couponcode}")
	public int Applycoupon(@PathVariable String couponcode,int discount) throws DemoException{
		return demoservice.Applydemo1(couponcode,discount);
	}
	@PostMapping("/cou")
	public ResponseEntity<String> adddemo1(@RequestBody demo1 dem ){
		demoservice.adddemo1(dem);	
		return new ResponseEntity<String>("coupons Sucessfully added",HttpStatus.OK); 
	}

}
