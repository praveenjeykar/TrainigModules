package com.cg.demo1.bean;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class demo1 {
	
	@Id
	private String couponcode;
	 private int discount;
	 private int price;
	 
 public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
public String getCouponcode() {
		return couponcode;
	}
	public void setCouponcode(String couponcode) {
		this.couponcode = couponcode;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	@Override
	public String toString() {
		return "demo1 [couponcode=" + couponcode + ", discount=" + discount + ", price=" + price + "]";
	}
	

}
