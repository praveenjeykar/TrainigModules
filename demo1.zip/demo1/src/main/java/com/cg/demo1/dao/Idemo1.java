package com.cg.demo1.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;
import com.cg.demo1.bean.demo1;

@Repository
public interface Idemo1 extends JpaRepository<demo1, String>{

	@Query("from demo1 where couponcode=:code")
	int getPriceByCoupon(@Param("code") String couponcode);
	
	@Query("from demo1 where discount=:dis")
	int getPriceByDiscount(@Param("dis") int discount);
	

}
