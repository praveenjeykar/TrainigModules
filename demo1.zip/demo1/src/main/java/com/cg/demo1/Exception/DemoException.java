package com.cg.demo1.Exception;

public class DemoException extends Exception {
	 public DemoException() {
		   super();
	   }
	   public DemoException(String msg) {
		   super(msg);
	   }
}
