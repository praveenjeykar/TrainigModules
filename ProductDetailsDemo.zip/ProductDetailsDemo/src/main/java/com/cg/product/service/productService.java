package com.cg.product.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.cg.product.bean.product;



public interface productService   {
   List<product> getAllProducts();
   product getproductById(int id);
   void updateproduct(product pro);
   void addproduct(product pro);
   void deleteproduct(int id);
   List<product> getproductByCategory(@Param("cat") String category);
   List<product> getproductByPrice(@Param("price1") int price1, @Param("price2") int price2);
}
