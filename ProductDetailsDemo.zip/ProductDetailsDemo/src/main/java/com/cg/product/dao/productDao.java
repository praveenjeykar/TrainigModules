package com.cg.product.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import com.cg.product.bean.product;

@Repository
public interface productDao extends JpaRepository<product,Integer> {

	@Query("from product where category=:cat")
    List<product> getproductByCategory(@Param("cat") String category);
   
    @Query("from Product where price between :price1 and :price2")     
    List<product> getproductByPrice(@Param("price1") int price1, @Param("price2") int price2);
	

}
