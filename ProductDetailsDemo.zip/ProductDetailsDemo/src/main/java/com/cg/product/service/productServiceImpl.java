package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.product;
import com.cg.product.dao.productDao;
@Service
public class productServiceImpl implements productService {
  @Autowired
	productDao ProductDao;
	@Override
	public List<product> getAllProducts() {
		return ProductDao.findAll();
	}
	@Override
	public product getproductById(int id) {
		return ProductDao.findById(id).get();
	}
	
	@Override
	public void updateproduct(product pro) {
		ProductDao.save(pro);
	}
	@Override
	public void addproduct(product pro) {
		ProductDao.save(pro);
	}
	@Override
	public void deleteproduct(int id) {
		ProductDao.deleteById(id);
	}
	@Override
	public List<product> getproductByCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<product> getproductByPrice(int price1, int price2) {
		// TODO Auto-generated method stub
		return null;
	}
	

	

}
