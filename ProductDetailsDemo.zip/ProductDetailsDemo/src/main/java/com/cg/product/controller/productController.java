package com.cg.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

import com.cg.product.bean.product;
import com.cg.product.service.productService;

@RestController
public class productController {
  @Autowired
  productService ProductService;
  
  @RequestMapping("/api/products")
  public List<product> getproduct(){
	  return ProductService.getAllProducts();  
  }
  
  @RequestMapping("/api/products/{id}")
  public product getproductById(@PathVariable int id){
	  return ProductService.getproductById(id);
  }
  
  @RequestMapping(value="/api/products/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteproduct(@PathVariable int id){
		ProductService.deleteproduct(id);
		return new ResponseEntity<String>
		("employee with the id "+id+" deleted",HttpStatus.OK);
	} 
  
  @RequestMapping(value="/api/products/{id}",method=RequestMethod.PUT)
 	public ResponseEntity<String> updateproduct(@RequestBody product pro){
 		ProductService.updateproduct(pro);
 		return new ResponseEntity<String>("Product Sucessfully updated",HttpStatus.OK);
 		
}
  @RequestMapping(value="/api/products/{id}",method=RequestMethod.POST)
 	public ResponseEntity<String> addproduct(@RequestBody product pro){
 		ProductService.addproduct(pro);
 		return new ResponseEntity<String>("Product Sucessfully added",HttpStatus.OK); 		
 }
}


